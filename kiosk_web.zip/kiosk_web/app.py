from flask import Flask, render_template, request, redirect, session, jsonify
import sqlite3
import datetime

app = Flask(__name__)
app.secret_key = "supersecretkey"

# ---------- DATABASE SETUP ----------
def init_databases():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT
    )""")
    conn.commit()
    conn.close()

    conn = sqlite3.connect("logbook.db")
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS logs(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                designation TEXT,
                blacklist_status TEXT,
                alcohol TEXT,
                mobile TEXT,
                face_status TEXT,
                final_status TEXT,
                timestamp TEXT
    )""")
    conn.commit()
    conn.close()

init_databases()

# ---------- LOGIN PAGE ----------
@app.route("/")
def home():
    return render_template("splash.html")

@app.route("/login_page")
def login_page():
    return render_template("login.html")

@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    password = request.form["password"]

    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
    user = c.fetchone()
    conn.close()

    if user:
        session["user"] = username
        return redirect("/dashboard")
    else:
        return "Incorrect username or password"

# ---------- SPLASH SCREEN ----------
@app.route("/splash")
def splash():
    return render_template("splash.html")

# ---------- DASHBOARD ----------
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect("/")
    return render_template("dashboard.html")

# ---------- VIEW ALL LOGS ----------
@app.route("/logs")
def view_logs():
    conn = sqlite3.connect("logbook.db")
    c = conn.cursor()
    c.execute("SELECT * FROM logs")
    logs = c.fetchall()
    conn.close()
    return render_template("logs.html", logs=logs)

# ---------- API FOR RASPBERRY PI TO SEND DATA ----------
@app.route("/add_log", methods=["POST"])
def add_log():
    data = request.json
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    conn = sqlite3.connect("logbook.db")
    c = conn.cursor()
    c.execute("""INSERT INTO logs(name, designation, blacklist_status, alcohol, mobile,
                face_status, final_status, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
              (data["name"], data["designation"], data["blacklist_status"],
               data["alcohol"], data["mobile"], data["face"], data["final"], timestamp))
    conn.commit()
    conn.close()

    return jsonify({"message": "Data received"}), 200

# ---------- History ----------
@app.route("/history")
def history():
    if "user" not in session:
        return redirect("/")

    conn = sqlite3.connect("logbook.db")
    c = conn.cursor()

    c.execute("""
        SELECT * FROM logs
        WHERE blacklist_status='Yes' OR final_status='Denied'
        ORDER BY timestamp DESC
    """)

    history_logs = c.fetchall()
    conn.close()

    return render_template("history.html", logs=history_logs)

# ---------- LOGOUT ----------
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect("/")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)


